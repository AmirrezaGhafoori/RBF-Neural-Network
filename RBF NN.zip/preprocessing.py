
import pandas as pd 
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
import random

input_file_name = './data/2clstrain1200.csv'
test_size = 0.3


#first we read the data form csv file with given file name 
def read_data ():
    data = pd.read_csv(input_file_name, names=["X0","X1","LABEL"])
    # print(data)
    return data 

#after that in thsi funciton we split train and test data with gi1`ven test_size
def split_train_test(data):
    train, test = train_test_split(data, test_size=test_size)
    return train , test
def generate_random_hex_color():
    random_number = random.randint(0,16777215)
    hex_number = str(hex(random_number))
    hex_number ='#'+ hex_number[2:]
    return hex_number

def show_data(data):
    colors = []
    label_list = make_label_list(data)
    label_colors = []
    for i in range(len(label_list)):
        colors.append(generate_random_hex_color())
    print(colors)
    for i in range (data.shape[0]):
        color = colors[label_list.index(data['LABEL'][i])]
        label_colors.append(color)
    for i in range (len(data['LABEL'])):
        plt.scatter(data['X0'][i], data['X1'][i], color=label_colors[i])
    plt.show()
def make_label_list(data):
    label_list = []
    labels = data['LABEL'].values
    for label in labels:
        if not (label in label_list):
            label_list.append(label)
    print(label_list)
    return label_list
    # print(label)


#this is the main function running other methods in order 
if __name__ == "__main__":
    data = read_data()
    print (data)
#     # train , test = split_train_test(data)
#     # print (train)
#     # print (data['X0'][0])
    show_data(data)
#     make_label_list(data)

