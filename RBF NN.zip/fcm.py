import pandas as pd
import preprocessing 
import random

#In this module we want to cluster our given data with FCM (Fuzzy C-Means)


#The controlling variables :
number_of_clusters = 2
number_of_iterations = 20
 #this is the dependencies matrix
# centers= []
data = preprocessing.read_data() #input data in pandas dataframe form 
train, test = preprocessing.split_train_test(data)
#With learning_data we choose which data we want to pass as input to fcm 

#first we give a random dependency to each data between 0 , 1 
def initiate_dependencies(mydata):
    learning_data = mydata
    columns = []
    u = []
    for i in range (number_of_clusters):
        columns.append('U'+str(i))
    
    #We want to make a N*C data frame where N is the number of datas and C is t number of clusters
    print('lenghth learning data=', learning_data.shape)
    for i in range(len(learning_data['X0'])):
        dep = []
        rand = []
        sum0 = 0.0
        for j in range(number_of_clusters):
            r =  random.uniform(0,1)
            rand.append(r)
            sum0 += r
        for i in range (len(rand)):
            dep.append(rand[i]/sum0)
        u.append(dep)
    print(len(u))
    u_pandas = pd.DataFrame(u, columns=columns) # making a pandas dataframe with u 2 diminsion list 
    return u_pandas
#now we have to find centroids of our clusters with these dependencies
def find_centers(u_pandas, mydata):
    centers = []
    learning_data = mydata
    for i in range(number_of_clusters):
        c = []
        # print("salam")

        x = 0
        y = 0
        dep_sum = 0
        for j in range (len(learning_data['X0'])):
            # print('salam')
            # print(learning_data)
            # print(learning_data['X0'][j])
            x += learning_data['X0'][j] * (u_pandas['U'+str(i)][j])**2
            # print(x)
            y += learning_data['X1'][j] * (u_pandas['U'+str(i)][j])**2
        for j in range(len(learning_data['X0'])):
            dep_sum += (u_pandas['U'+str(i)][j])**2 #this is the sum of dependencies
        c_x = x/dep_sum
        c_y = y/dep_sum
        c.append(c_x)
        c.append(c_y)
        centers.append(c)  
    # print('male maneeee',centers) 
    return centers  
def update_dependencies(u_pandas, centers, mydata):
    #for calculating dependency we put m = 2
    #loop for updating dependencies
    learning_data = mydata
    print("STAAAART")
    print("updaaaaaate")
    print('upandas shaaape=', u_pandas.shape)
    print('data shaaape=', mydata.shape)
    centers = pd.DataFrame(centers, columns=['X0', 'X1'])
    print('centersss shape=', centers.shape)

    for i in range(len(u_pandas['U0'])):
        for j in range (number_of_clusters):
            dist_sum = 0
            for k in range(number_of_clusters):
                #This is the distance from center j 
                dj2 = (learning_data['X0'][i] - centers['X0'][j])**2 + (learning_data['X1'][i] - centers['X1'][j])**2
                #This is the distance from center k 
                dk2 = (learning_data['X0'][i] - centers['X0'][k])**2 + (learning_data['X1'][i] - centers['X1'][k])**2

                d2 = dj2/dk2

                dist_sum += d2
            u_pandas['U'+str(j)][i] = 1/dist_sum
    print("EEEEEEND")
#We will call this function and find the centers and u of data for rbf module 
def fuzzy_cmeans(mydata):
    learning_data = mydata
    u_pandas = initiate_dependencies(learning_data) #pandas dataframe of dependencies
    for i in range(number_of_iterations): 
        print("FCM iteration = ", i)   
        centers = find_centers(u_pandas, learning_data)
        update_dependencies(u_pandas, centers, learning_data)
    v_pandas = pd.DataFrame(centers, columns=['X0', 'X1'])
   
    return v_pandas, u_pandas

def calc_dependencies(centers, mydata):
    learning_data = mydata
    u_pandas = initiate_dependencies(learning_data)
    print('upandas shaaape=', u_pandas.shape)
    print('data shaaape=', mydata.shape)
    print('centersss shape=', centers.shape)
    update_dependencies(u_pandas, centers, learning_data)
    return u_pandas


# if __name__ == "__main__":
#     print(data)
#     u_pandas = initiate_dependencies() #pandas dataframe of dependencies
#     # print(u)
#     print(u_pandas.sum(axis=0, skipna= True)['U0'])
#     for i in range(number_of_iterations):    
#         centers = find_centers()
#         update_dependencies()
#     print(u_pandas)

#     print(centers)

