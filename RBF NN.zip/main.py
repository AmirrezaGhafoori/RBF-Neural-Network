import rbf
import fcm
import preprocessing
import matplotlib.pyplot as plt

#here we have to first train the rbf with train data and then test the network with test data

data = preprocessing.read_data()
train, test = preprocessing.split_train_test(data)

# label_list = preprocessing.make_label_list(train)
label_list = preprocessing.make_label_list(data)
train_cordinates = train.drop(columns=['LABEL'])  
train_cordinates = train_cordinates.reset_index(drop=True)
train = train.reset_index(drop=True)

test_cordinates = test.drop(columns=['LABEL'])
test_cordinates = test_cordinates.reset_index(drop=True)
test = test.reset_index(drop=True)

#first we train the W matrix with train data 

def calc_accuracy(real, calculated):
    true_labels = 0
    all_labels = len(real)
    for i in range(all_labels):
        if (real[i] == calculated[i]):
            true_labels += 1
    accuracy = true_labels/all_labels
    return accuracy

def train_rbf():
    V, U = fcm.fuzzy_cmeans(train)
    G = rbf.make_G_matrix(train_cordinates, U, V)
    Y = rbf.make_Y_matrix(train, label_list)
    input_labels = train['LABEL'].values
    #This is the weight matrix that we learn it from train datas labels and G matrices
    W = rbf.make_W_matrix(G, Y)
    output_labels = rbf.calc_y(G, W)
    labels_index = output_labels
    for i in range (len(output_labels)):
        output_labels[i] = label_list[output_labels[i]]
    # print(output_labels)
    accuracy = calc_accuracy(input_labels, output_labels)
    labeled_train_cordinates = train_cordinates
    labeled_train_cordinates['LABEL'] = output_labels

    #We return learned Weights and labeled train data and accuracy of training data
    return W, V, labeled_train_cordinates, accuracy, labels_index, input_labels

def test_rbf(W, V):
    print('test shape= ', test.shape)
    U = fcm.calc_dependencies(V, test)
    G = rbf.make_G_matrix(test_cordinates, U, V)
    Y = rbf.make_Y_matrix(test, label_list)
    input_labels = test['LABEL'].values
    output_labels = rbf.calc_y(G, W)
    labels_index = output_labels
    # print("LABELSSSSS INDEXXXXX=====", labels_index)
    for i in range (len(output_labels)):
        output_labels[i] = label_list[output_labels[i]]
    accuracy = calc_accuracy(input_labels, output_labels)
    labeled_test_cordinates = test_cordinates
    labeled_test_cordinates['LABEL'] = output_labels
    return labeled_test_cordinates, accuracy, labels_index, input_labels

def draw_test(color_list, input_labels, labels_index, data, centers):
    center_color = 'Blue'
    # print(len(color_list))
    # print("LABELLLS INDEX IN DRAAAAW", labels_index)
    for i in range(data.shape[0]):
        if input_labels[i] == labels_index[i]:
            # print(labels_index[i])
            color = color_list[int(labels_index[i]) - 1]
        else:
            color = 'Red'
        plt.scatter(data['X0'][i], data['X1'][i], color=color)
    for i in range(centers.shape[0]):
        plt.scatter(centers['X0'], centers['X1'], color=center_color)
    plt.show()
def draw(data, color_list, centers):
    center_color = 'Blue'
    for i in range(data.shape[0]):
        color = color_list[int(data['LABEL'][i]) - 1]
        plt.scatter(data['X0'][i], data['X1'][i], color=color)
    for i in range(centers.shape[0]):
        plt.scatter(centers['X0'][i], centers['X1'][i], color=center_color)
    plt.show()
# def clustering_in_plate(V, U):
#         plt.xlim()
#         plt.ylim()
#         x_range = np.arange(-10, 30, 0.1)
#         y_range = np.arange(-10, 30, 0.1)
#         xx, yy = np.meshgrid(x_range, y_range)
#         cmap = plt.get_cmap('Paired')
#         zz = np.zeros(xx.shape)
#         for i in range(zz.shape[0]):
#             for j in range(zz.shape[1]):
#                 uik = []
#                 x_vector = [xx[i][j], yy[i][j]]
#                 for ci in self.C_matrix:
#                     temp = self.get_uik(x_vector, ci)
#                     uik.append(temp)
#                 zz[i][j] = np.argmax(uik)
#         pyplot.pcolormesh(xx, yy, zz, cmap=cmap)


if __name__ == "__main__":
    #first we train our rbf and find the W matrix   
    W,V, labeled_train_cordinates, accuracy_train, labels_index_train, input_labels_train = train_rbf()
    print('Train acc = ', accuracy_train)
    labeled_test_cordinates, accuracy_test, labels_index_test, input_labels_test = test_rbf(W, V)
    print('Test acc=', accuracy_test)
    print(V)
    # print(labeled_train_cordinates)
    # for i in range(labeled_train_cordinates.shape[0]):
    #     plt.scatter(labeled_train_cordinates['X0'][i], labeled_train_cordinates['X1'][i], color='Black')
    # for i in range(V.shape[0]):
    #     plt.scatter(V['X0'][i], V['X1'][i],color='Red')
    # plt.show()
    colors = ['Gray', 'Black', 'Green', 'Yellow']
    draw_test(colors, input_labels_test, labels_index_test, test_cordinates, V)
    draw(train, colors, V)