import fcm
import preprocessing
import numpy as np
import pandas as pd


gama = 0.001                  

def calc_ci(data1, U, V, i):
    #data rgument is the dataframe of all input data
    #This method will calculate Ci for Vi which is the i th center 
    #m is 2 here
    # print(data1.shape)
    sum0 = np.zeros((data1.shape[1], data1.shape[1]))
    sum1 = 0.0

    vi = V.loc[i].values
    for k in range (len(data1['X0'])):
        u = U['U'+str(i)][k]
        xk = data1.loc[k].values
        sub = np.atleast_2d(np.subtract(xk, vi))
        # print(sub.T)
        sum0 += (u)**2  * np.matmul(np.transpose(sub), sub)
        sum1 += (u)**2
    ci = sum0/sum1
   
    # print (ci)
    return ci
def calc_gi(data1, U, V, ci, k, i):
    #This method will calculate the gi for Vi of Xk input  

    xk = data1.loc[k].values
    vi = V.loc[i].values
    sub = np.atleast_2d(np.subtract(xk, vi))
    # print(ci)
    ci_inverse = np.linalg.pinv(ci)
    # print(np.shape(sub))
    # print(np.shape(np.transpose(sub)))
    e_power = -1 * gama * np.matmul(np.matmul(sub, ci_inverse), np.transpose(sub))
    gi = np.exp(e_power)
    return float(gi)
#data rgument is the dataframe of all input data

#first we want to make G matrix which is the output of all data for all hidden layer nodes
def make_G_matrix(data1, U, V):
    G = []
    c = []
    column_label = []
    for i in range (V.shape[0]):
        ci = calc_ci(data1, U, V, i)
        c.append(ci)
        column_label.append('V'+str(i))
    for k in range(data1.shape[0]):

        g = []
        for i in range (V.shape[0]):
            gi_xk = calc_gi(data1, U, V, c[i], k, i)
            g.append(gi_xk)
        # print('k = '+str(k))
        G.append(g)
    # G_pandas = pd.DataFrame(G, columns=column_label)
    return G

def make_Y_matrix(data, label_list):
    n = data.shape[0]

    c = len(label_list)
    Y = np.zeros((n, c))
    labels = data['LABEL'].values
    for i in range (len(labels)):
        c = label_list.index(labels[i])
        Y[i, c] = 1
    # print(Y)
    return Y
def make_W_matrix(G, Y):
    gt = np.transpose(G)
    g = G
    gtg_inverse = np.linalg.pinv(np.matmul(gt, g))
    ggg = np.matmul(gtg_inverse, gt)
    W = np.matmul(ggg, Y)
    return W
def calc_y(G, W):
    #here we calculate the output 
    gw = np.matmul(G, W)
    y_hat = []
    number_of_data = np.shape(gw)[0]
    for i in range (number_of_data):
        arr = gw[i]
        result = np.where(arr == np.amax(arr))
        y_hat.append(int(result[0]))
    
    print(gw)
    print(y_hat)
    return(y_hat)


if __name__ == "__main__":
    pass
    # # print(data)
    # k = data1.loc[0].values
    # print(k)
    # c0 = calc_ci(U,data1, V, 0 )
    # print (c0)
    # g0 = calc_gi(data1, U, V, 5, 0)
    # print(g0)
    # print (V.shape)
    # G = make_G_matrix(data1, U, V)
    # print(G)
    # print(G_pandas['V0'].values.item(0))
    # Y = make_Y_matrix(train, label_list)
    # print(Y)
    # print(np.shape(G))
    # print(np.shape(Y))
    # W = make_W_matrix(G, Y)
    # print(W)
    # output = calc_y(G, W)
    # print(output)
    # print(data.loc[0]['X0'])
    # print(data)
    # my = transform_to_list(data,3)
    # print(my)